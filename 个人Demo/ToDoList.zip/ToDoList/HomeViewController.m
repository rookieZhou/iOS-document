//
//  HomeViewController.m
//  ToDoList
//
//  Created by mmix on 14-6-22.
//  Copyright (c) 2014年 mmix. All rights reserved.
//

#import "HomeViewController.h"
#import "AddThingViewController.h"
#import "ACMacros.h"
#import "EditViewController.h"
#import "ZMTableViewCell.h"
#import "TimeHelper.h"

@interface HomeViewController ()
<UITextFieldDelegate, UITableViewDelegate, UITableViewDataSource,EditViewControllerDelegate,AddThingViewControllerDelegate>

@property (strong, nonatomic) UITableView *tableView;

@end

@implementation HomeViewController

static NSString *kTableViewCellIndentifer = @"reuseTableViewCellIndentifer";

static NSString *kDataSource = @"dataSource";

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        [self setupNavigationItem];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
//    if (IOS7_OR_LATER) {
//        self.edgesForExtendedLayout = UIRectEdgeNone;
//    }
    self.title = @"Home";

    self.tableView.backgroundColor = [UIColor clearColor];
    self.tableView.delegate = (id)self;
    self.tableView.dataSource = (id)self;
    [self setupFooterView];
    [self.view addSubview:self.tableView];
    
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.tableView reloadData];
   
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - getter

- (UITableView *)tableView
{
    if (nil == _tableView) {
        CGRect rect = CGRectMake(0, 0, Main_Screen_Width, Main_Screen_Height);
        _tableView = [[UITableView alloc] initWithFrame:rect style:UITableViewStylePlain];
    }
    return _tableView;
}



#pragma mark - custom methods
- (void)setupNavigationItem
{
    UIImage *image = [UIImage imageNamed:@"menu_add"];
    UIButton *addButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [addButton setBackgroundImage:image forState:UIControlStateNormal];
    addButton.frame = CGRectMake(0, 0, 20, 20);
    [addButton addTarget:(id)self action:@selector(addButtonTouchUpInsideEventHandle:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *barButtonItem = [[UIBarButtonItem alloc] initWithCustomView:addButton];
    self.navigationItem.rightBarButtonItem = barButtonItem;
}

- (void)setupFooterView
{
    CGRect rect = CGRectMake(0, 0, 320, 0.1);
    UIView *view = [[UIView alloc] initWithFrame:rect];
    view.backgroundColor = [UIColor redColor];
    [self.tableView setTableFooterView:view];
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataSource.count;
}

// 二维数组退化成一纬数组
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return  1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ZMTableViewCell *tableViewCell = [tableView dequeueReusableCellWithIdentifier:kTableViewCellIndentifer];
    if (tableViewCell == nil) {
        tableViewCell = [[ZMTableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:kTableViewCellIndentifer];
    }
    tableViewCell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    tableViewCell.textLabel.text = self.dataSource[indexPath.row][@"title"];
    tableViewCell.detailTextLabel.text =self.dataSource[indexPath.row][@"content"];
    tableViewCell.timeLabel.text = self.dataSource[indexPath.row][@"time"];
    
    return tableViewCell;
}

// 如果不设置,所有tableViewCell都可以编辑属性。如果设置为NO，全部不可以编辑.可以利用indexPath定制设置可以编辑的tableViewCell
- (BOOL)tableView:(UITableView *)tableView
canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}


//
- (void)tableView:(UITableView *)tableView
commitEditingStyle:(UITableViewCellEditingStyle)editingStyle
forRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    if(editingStyle == UITableViewCellEditingStyleDelete){
        [self.dataSource removeObject:self.dataSource[indexPath.row]];
        [userDefaults setObject:self.dataSource forKey:kDataSource];
        NSArray *data = [userDefaults objectForKey:kDataSource];
        self.dataSource = [data mutableCopy];
        [self.tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }
}




#pragma  mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    EditViewController *editViewController = [[EditViewController alloc] init];
    editViewController.delegate = (id)self;
    NSMutableDictionary *itemData = self.dataSource[indexPath.row];
    NSString *title = itemData[@"title"];
    NSString *content = itemData[@"content"];
    editViewController.titleString = title;
    editViewController.contentString = content;
    [self.navigationController pushViewController:editViewController animated:NO];
}





#pragma  mark - target-action
- (void)addButtonTouchUpInsideEventHandle:(UIButton *)button
{
    AddThingViewController *addThingViewController = [[AddThingViewController alloc] init];
    addThingViewController.delegate = (id)self;
    [self.navigationController pushViewController:addThingViewController animated:NO];
}

#pragma mark - EditViewControllerDelegate

- (void)editViewController:(EditViewController *)editViewController
                     title:(NSString *)title
             contentString:(NSString *)contentString
{
    if (![title isEqualToString:@""] && title != nil) {
        NSIndexPath *indexPath = [self.tableView indexPathForSelectedRow];
        NSMutableDictionary *dict = self.dataSource[indexPath.row];
        [dict setValue:title forKey:@"title"];
        [dict setValue:contentString forKey:@"content"];
        [dict setValue:[TimeHelper createdDate] forKey:@"time"];
        
        NSUserDefaults *userDefaults= [NSUserDefaults standardUserDefaults];
        [userDefaults setObject:[self.dataSource copy] forKey:kDataSource];
        [userDefaults synchronize];
        self.dataSource = [userDefaults objectForKey:kDataSource];
    }

}


#pragma mark - AddThingViewControllerDelegate


- (void)addTitle:(NSString *)titleName content:(NSString *)contentName
{
    if (![titleName isEqualToString:@""] && titleName!=nil) {
        NSMutableDictionary *dict = [
                                      @{
                                           @"title":titleName,
                                           @"content":contentName,
                                           @"time":[TimeHelper createdDate]
                                       }
                                     mutableCopy];
        [self.dataSource addObject:dict];
        [[NSUserDefaults standardUserDefaults] setObject:self.dataSource forKey:kDataSource];
        [[NSUserDefaults standardUserDefaults] synchronize];
        NSLog(@"添加结果写入文件%@",self.dataSource);
    }
}




@end
