//
//  ZMTableViewCell.h
//  ToDoList
//
//  Created by mmix on 14-6-29.
//  Copyright (c) 2014年 mmix. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZMTableViewCell : UITableViewCell
@property (strong, nonatomic) UILabel *timeLabel;
@end
