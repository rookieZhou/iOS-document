//
//  AddThingViewController.m
//  ToDoList
//
//  Created by mmix on 14-6-22.
//  Copyright (c) 2014年 mmix. All rights reserved.
//

#import "AddThingViewController.h"
#import "ACMacros.h"
#import "HomeViewController.h"

@interface AddThingViewController ()<UITextFieldDelegate>

@property (strong, nonatomic) UITextField *titleTextField;
@property (strong, nonatomic) UITextField *contentTextField;
@property (strong, nonatomic) UIButton *finishButton;

@end

@implementation AddThingViewController


# pragma mark - 控制器生命周期

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {

    }
    return self;
}

- (void)viewDidLoad
{
     [super viewDidLoad];
    
    if (IOS7_OR_LATER) {
        self.edgesForExtendedLayout = UIRectEdgeNone;
    }
    
    self.title = @"Add item";
 
    [self setupTitleTextField];
    [self setupContentTextField];
   
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
}


# pragma mark - custom method

- (void)setupTitleTextField
{
    self.titleTextField = [[UITextField alloc] initWithFrame:CGRectMake(0, 0, Main_Screen_Width, 34)];
    [self.titleTextField setPlaceholder:@"标题"];
    [self.titleTextField setTextColor:[UIColor blueColor]];
    self.titleTextField.textAlignment = NSWritingDirectionLeftToRight;
    self.titleTextField.font = [UIFont systemFontOfSize:34];
    [self.view addSubview:self.titleTextField];

}

- (void)setupContentTextField
{
    self.contentTextField = [[UITextField alloc] initWithFrame:CGRectMake(0, 34, Main_Screen_Width, 44)];
    self.contentTextField.backgroundColor = [UIColor clearColor];
    self.contentTextField.delegate = (id)self;
    self.contentTextField.placeholder = @"输入公司名";
    [self.view addSubview:self.contentTextField];
    self.contentTextField.delegate = (id)self;
}

# pragma  mark - UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
   return  [textField resignFirstResponder];
}


- (void)viewWillDisappear:(BOOL)animated
{
    if([_delegate respondsToSelector:@selector(addTitle:content:)]){
        [self.delegate addTitle:self.titleTextField.text content:self.contentTextField.text];
    }

}



@end
