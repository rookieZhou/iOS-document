//
//  main.m
//  ToDoList
//
//  Created by mmix on 14-6-22.
//  Copyright (c) 2014年 mmix. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
