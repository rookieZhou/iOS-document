//
//  AddThingViewController.h
//  ToDoList
//
//  Created by mmix on 14-6-22.
//  Copyright (c) 2014年 mmix. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol AddThingViewControllerDelegate <NSObject>

- (void)addTitle:(NSString *)titleName content:(NSString *)contentName;

@end


@interface AddThingViewController : UIViewController

@property (weak, nonatomic) id<AddThingViewControllerDelegate> delegate;

@end
