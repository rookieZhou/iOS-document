
//  EditViewController.h
//  ToDoList
//
//  Created by mmix on 14-6-26.
//  Copyright (c) 2014年 mmix. All rights reserved.
//

#import <UIKit/UIKit.h>

@class EditViewController;

@protocol EditViewControllerDelegate <NSObject>
@optional
- (void)editViewController:(EditViewController *)editViewController
                     title:(NSString *)title
             contentString:(NSString *)contentString;

@end


@interface EditViewController : UIViewController

// 保存从HomeViewController那里传进来的数据
@property (strong, nonatomic) NSString *titleString;
@property (strong, nonatomic) NSString *contentString;

@property (weak, nonatomic) id<EditViewControllerDelegate> delegate;
@end
