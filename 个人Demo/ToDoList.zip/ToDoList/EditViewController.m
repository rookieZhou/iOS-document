//
//  EditViewController.m
//  ToDoList
//
//  Created by mmix on 14-6-26.
//  Copyright (c) 2014年 mmix. All rights reserved.
//

#import "EditViewController.h"
#import "ACMacros.h"
#import "HomeViewController.h"

@interface EditViewController ()

@property (strong, nonatomic) UITextField *titleTextField;
@property (strong, nonatomic) UITextField *contentTextField;
@property (strong, nonatomic) UIButton *finishButton;

@end

@implementation EditViewController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        if (IOS7_OR_LATER) {
            self.edgesForExtendedLayout = UIRectEdgeNone;
        }
    }
    return self;
}

- (void)viewDidLoad
{
    self.title = @"Edit";
    [super viewDidLoad];
    
    [self setupTitleLabel];
    [self setupContentTextField];
    [self setupFinishButton];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];

}

- (void)setupTitleLabel
{

    CGRect rect = CGRectMake(20, 44, 280, 44);
    self.titleTextField = [[UITextField alloc] initWithFrame:rect];
    self.titleTextField.placeholder = @"title";
    self.titleTextField.font = [UIFont systemFontOfSize:17];
    self.titleTextField.delegate = (id)self;
    self.titleTextField.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.titleTextField];
    
    // 填充内容
    if (self.titleString != nil && ![self.titleString isEqual:@""]) {
        self.titleTextField.text = self.titleString;
    }
   
}

- (void)setupContentTextField
{
    CGRect rect = CGRectMake(20, 88, 280, 44);
    self.contentTextField = [[UITextField alloc] initWithFrame:rect];
    self.contentTextField.placeholder = @"输入内容";
    self.contentTextField.font = [UIFont systemFontOfSize:12];
    self.contentTextField.backgroundColor = [UIColor whiteColor];
    self.contentTextField.delegate = (id)self;
    [self.view addSubview:self.contentTextField];
    
    
    if (self.contentString != nil && ![self.contentString isEqualToString:@""]){
        self.contentTextField.text = self.contentString;
    }

}

- (void)setupFinishButton
{
    CGRect rect = CGRectMake(20, 524, 280, 44);
    self.finishButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    self.finishButton.frame = rect;
    [self.view addSubview:self.finishButton];
}



- (BOOL)textFieldShouldReturn:(UITextField *)textField
{   
    return [textField resignFirstResponder];
}


- (void)viewWillDisappear:(BOOL)animated
{
    if ( [_delegate respondsToSelector:@selector(editViewController:title:contentString:)] )
    {
        [self.delegate editViewController:self
                                    title:self.titleTextField.text
                            contentString:self.contentTextField.text];
    }
}



@end
