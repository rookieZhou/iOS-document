//
//  TimeHelper.m
//  ToDoList
//
//  Created by mmix on 14-6-29.
//  Copyright (c) 2014年 mmix. All rights reserved.
//

#import "TimeHelper.h"

@implementation TimeHelper

// 废弃
//+(NSString *)currentDateDescription
//{
//    NSDate *date = [NSDate date];
//    return date.description;
//}

+ (NSString *)createdDate
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    return   [dateFormatter stringFromDate:[NSDate date]];
    

}


@end
