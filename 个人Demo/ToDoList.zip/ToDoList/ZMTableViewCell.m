//
//  ZMTableViewCell.m
//  ToDoList
//
//  Created by mmix on 14-6-29.
//  Copyright (c) 2014年 mmix. All rights reserved.
//

#import "ZMTableViewCell.h"

@interface ZMTableViewCell ()

@end


@implementation ZMTableViewCell

# pragma mark - 控制器生命周期
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self setupTimeLabel];
    }
    return self;
}



- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

#pragma mark - customMethods
- (void)setupTimeLabel
{
    CGRect rect = CGRectMake(160, 30, 90, self.bounds.size.height - 30);
    self.timeLabel = [[UILabel alloc] initWithFrame:rect];
    self.timeLabel.backgroundColor = [UIColor clearColor];
    [self.timeLabel setText:@"时间"];
    self.timeLabel.textAlignment = NSTextAlignmentCenter;
    [self.timeLabel setTextColor:[UIColor blueColor]];
    [self.timeLabel setFont:[UIFont systemFontOfSize:13]];
    [self.contentView addSubview:self.timeLabel];
}

@end
