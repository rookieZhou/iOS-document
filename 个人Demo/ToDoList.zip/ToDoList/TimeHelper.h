//
//  TimeHelper.h
//  ToDoList
//
//  Created by mmix on 14-6-29.
//  Copyright (c) 2014年 mmix. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface TimeHelper : NSObject

// 废弃
//+(NSString *)currentDateDescription;

+(NSString *)createdDate;


@end
